# lista-2

O exercício 1 implementa um tipo abstrato de dados para trabalhar com números complexos.
O exercício 2 implementa um tipo abstrato de dados para trabalhar com matrizes.
Ambos os exercícios possuem, no main.c, uma forma de interação com o usuário para efetuar operações sobre o TAD.

Atenção: todos os casos teste e compilação foram realizadas no Linux, utilizando o compilador GCC.
É recomendado que o programa seja testado e avaliado em um ambiente Linux, já que os compiladores de Windows
podem apresentar resultados diferentes.

As instruções de uso e compilação de cada exercício estão expostas nos arquivos instructions.md dentro de cada diretório.
Foi implementado um arquivo Makefile para cada exercício, para auxiliar na compilação.

Alunos:
- Breno Henrique Pelegrin da Silva: implementou o tad-complex
- Pedro Martins de Oliveira: implementou o tad-matrix
